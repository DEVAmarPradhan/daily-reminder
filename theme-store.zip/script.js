// Theme Toggle
const lightBtn = document.getElementById('lightBtn');
const darkBtn = document.getElementById('darkBtn');
lightBtn.addEventListener('click', () => { document.body.classList.remove('dark'); localStorage.setItem('theme','light'); });
darkBtn.addEventListener('click', () => { document.body.classList.add('dark'); localStorage.setItem('theme','dark'); });
if(localStorage.getItem('theme')==='dark'){ document.body.classList.add('dark'); }

// Cart System
const cartBtn=document.getElementById('cartBtn'); const cartSidebar=document.getElementById('cartSidebar');
const closeCart=document.getElementById('closeCart'); const cartItems=document.getElementById('cartItems');
const cartTotal=document.getElementById('cartTotal'); const cartCount=document.getElementById('cartCount');
let cart=[]; cartBtn.addEventListener('click',()=>cartSidebar.classList.add('active'));
closeCart.addEventListener('click',()=>cartSidebar.classList.remove('active'));
document.querySelectorAll('.add-cart').forEach(btn=>{ btn.addEventListener('click',e=>{
  const card=e.target.closest('.theme-card'); const name=card.dataset.name; const price=parseFloat(card.dataset.price);
  const item=cart.find(i=>i.name===name); if(item){ item.qty++; } else { cart.push({name,price,qty:1}); }
  updateCart(); }); });
function updateCart(){ cartItems.innerHTML=''; let total=0;
  cart.forEach((item,i)=>{ total+=item.price*item.qty; const li=document.createElement('li'); li.innerHTML=`${item.name} x${item.qty} - $${(item.price*item.qty).toFixed(2)} <button onclick="removeItem(${i})">❌</button>`; cartItems.appendChild(li); });
  cartTotal.textContent=total.toFixed(2); cartCount.textContent=cart.length; }
function removeItem(i){ cart.splice(i,1); updateCart(); }